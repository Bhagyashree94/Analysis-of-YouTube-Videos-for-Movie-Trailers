YouTube Movie Trailer Analysis ReadMe

Step 1:Install the google apis required for this project mentioned below:
	
pip install google-api-python-client
pip install oauth2client


Step 2: Run the python file to create the data for analysis
CreateRawData.py file

Step 3: Run the spark code
SparkAnalysis.py

Step 4: View Results
See the results in result folder

Note: Modify the path files as per system directory
